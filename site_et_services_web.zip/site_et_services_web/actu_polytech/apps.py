from django.apps import AppConfig


class ActuPolytechConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'actu_polytech'
